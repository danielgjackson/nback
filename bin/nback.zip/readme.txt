N-Backer
========


About
-----

N-back is a secondary task that loads working memory. The numeric n-back task requires the volunteer 
to listen to a stream of presented digits and to say the digit they heard 'n-steps' back in time.
(e.g. in the 2-back sequence 3 1 6 9, one would be asked to say 3 on hearing 6, 1 on hearing 9 and so on).

N-Backer uses speech synthesis and recognition to automate the presentation and scoring of this task.
The tool aims to simulate in normal volunteers some of the symptoms observed in, for example, patients 
in the early stages of dementia when they carry out multi-step tasks.


Quick start
-----------

* Copy the executable to a Windows XP computer.

* Run "nback-xp.exe", and press the 'Play' button.

* Read into the computer's microphone the digit you heard '1-back' (e.g. in the sequence 3 1 6 9, say 3 on hearing 1, 1 on hearing 6, and so on).


Troubleshooting
---------------

* "nback-xp.exe" Should be run on Windows XP
  - it won't work properly on Windows Vista or Windows 7, as the speech recognition will also recognize system commands.
  - "nback-inproc.exe" is an attempt to use an in-process, non-shared recognizer that will not detect system commands -- but this is not well tested.

* If it doesn't start at all, ensure the Microsoft .NET 3.5 SP1 installed:
  - http://www.microsoft.com/download/en/details.aspx?id=21

* To obtain the synthesized voices that it was designed for, install the Microsoft Speech SDK 5.1:
  - http://www.microsoft.com/download/en/details.aspx?id=10121 (SpeechSDK51.exe)

* It is designed for use with head-mounted microphone 
  - check in the Speech Recognition Control Panel that the correct audio input is selected.


